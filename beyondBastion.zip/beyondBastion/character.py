import constant
import outputgen
import time


class Character:
    def __init__(self, name, subj_pronoun, strength, intelligence, charisma, vitality, endurance, composure):
        self.name = name.upper()
        self.subj_pronoun = subj_pronoun

        if self.subj_pronoun == "she":
            self.obj_pronoun = "her"
            self.pos_pronoun = "her"

        if self.subj_pronoun == "they":
            self.obj_pronoun = "their"
            self.pos_pronoun = "their"

        if self.subj_pronoun == "he":
            self.obj_pronoun = "him"
            self.pos_pronoun = "his"

        self.strength = strength  # determines carry weight, base attack power
        self.intelligence = intelligence
        self.charisma = charisma

        self.vitality = vitality  # determines max health
        self.endurance = endurance  # determines max energy
        self.composure = composure  # determines max sanity, base defense

        self.max_health, self.health = 100, 100
        self.max_energy, self.energy = 100, 100
        self.max_sanity, self.sanity = 100, 100
        self.attack = 1
        self.defense = 1

        self.equipment = {"head": None,
                          "body": None,
                          "weapon": None,
                          "curio": None}

        self.update_stats()

        self.health = self.max_health
        self.energy = self.max_energy
        self.sanity = self.max_sanity

    def update_attack(self):
        self.attack = 1 + round(self.strength / 3)
        bonus_atk = 0
        for i in self.equipment:
            if self.equipment[i] is not None:
                bonus_atk += self.equipment[i].atk_mod
        self.attack += bonus_atk

        return self.attack

    def update_defense(self):
        self.defense = 1 + round(self.composure / 3)
        bonus_def = 0
        for i in self.equipment:
            if self.equipment[i] is not None:
                bonus_def += self.equipment[i].modifiers["DEF"]
        self.defense += bonus_def
        return self.defense

    def update_stats(self):
        self.max_health = 100 + round(self.vitality * constant.STAT_CONVERSION)\
                            - round((constant.STAT_CAP * constant.STAT_CONVERSION) / 2)
        if self.health > self.max_health:
            self.health = self.max_health

        self.max_energy = 100 + round(self.endurance * constant.STAT_CONVERSION)\
                            - round((constant.STAT_CAP * constant.STAT_CONVERSION) / 2)
        if self.energy > self.max_energy:
            self.energy = self.max_energy

        self.max_sanity = 100 + round(self.composure * constant.STAT_CONVERSION)\
                            - round((constant.STAT_CAP * constant.STAT_CONVERSION) / 2)
        if self.sanity > self.max_sanity:
            self.sanity = self.max_sanity

        self.update_attack()
        self.update_defense()

    def take_damage(self, stat, amount):  # returns true if damage was fatal
        match stat:
            case "health":
                self.health -= amount
                if self.health <= 0:
                    print(self.name + " has died of blood loss.")
                    time.sleep(1)
                    return True
            case "energy":
                self.energy -= amount
                if self.energy <= 0:
                    print(self.name + " has died of exhaustion.")
                    time.sleep(1)
                    return True
            case "sanity":
                self.sanity -= amount
                if self.sanity <= 0:
                    print(self.name + " has gone insane.")
                    time.sleep(1)
                    return True
            case "vitality":
                self.vitality -= amount
                if self.vitality <= 0:
                    print(self.name + " has died of illness.")
                    time.sleep(1)
                    return True
            case "endurance":
                self.endurance -= amount
                if self.endurance <= 0:
                    print(self.name + " has died of Endurance.")
                    time.sleep(1)
                    return True
            case "composure":
                self.composure -= amount
                if self.composure <= 0:
                    print(self.name + " has died of Composure.")
                    time.sleep(1)
                    return True
            case "intelligence":
                self.intelligence -= amount
                if self.intelligence <= 0:
                    print(self.name + " has died of brain damage.")
                    time.sleep(1)
                    return True
            case "intelligence":
                self.charisma -= amount
                if self.charisma <= 0:
                    print(self.name + " has died of Charisma.")
                    time.sleep(1)
                    return True
        return False

    def stat_col(self, label, stat):
        column_width = int((constant.OUTPUT_WIDTH - 2) / 4)
        column = "| " + label + ": "
        column += outputgen.n_char_str(" ", column_width - len(column) - len(str(stat))) + str(stat) + " "
        return column

    def stat_col_equipment(self, label, slot):
        column_width = int((constant.OUTPUT_WIDTH - 2) / 2)

        if self.equipment[slot] is None:
            value_string = ""
        else:
            value_string = self.equipment[slot].item.name

        column = "| " + label + ": "
        column += outputgen.n_char_str(" ", column_width - len(column) - len(value_string)) + value_string + " "
        return column

    def stat_col_fraction(self, label, stat, max_stat):
        column_width = int((constant.OUTPUT_WIDTH - 2) / 2)
        column = "| " + label + ": "
        fraction = str(stat) + "/" + str(max_stat)
        column += outputgen.n_char_str(" ", column_width - len(column) - len(fraction)) + fraction + " "
        return column

    def equipment_row(self, label, slot):
        row = self.stat_col_equipment(label, slot) + "| "
        if self.equipment[slot] is not None:
            num_printed = 0
            modifier_list = self.equipment[slot].modifiers
            for modifier_name in modifier_list:
                if modifier_list[modifier_name] > 0:
                    num_printed += 1
                    if num_printed >= 2:
                        row += ", "
                    row += modifier_name + " +" + str(modifier_list[modifier_name])
                elif modifier_list[modifier_name] < 0:
                    num_printed += 1
                    if num_printed >= 2:
                        row += ", "
                    row += modifier_name + " " + str(modifier_list[modifier_name])
        row += outputgen.n_char_str(" ", constant.OUTPUT_WIDTH - len(row) - 1) + "|"
        print(row)

    def stat_sheet(self):
        outputgen.clear()
        outputgen.print_menu_header(self.name.upper())

        # BASE STATS

        row = self.stat_col_fraction("Health", self.health, self.max_health)
        row += self.stat_col("Vitality", self.vitality)
        row += self.stat_col("Strength", self.strength) + "|"
        print(row)

        row = self.stat_col_fraction("Energy", self.energy, self.max_energy)
        row += self.stat_col("Endurance", self.endurance)
        row += self.stat_col("Intelligence", self.intelligence) + "|"
        print(row)

        row = self.stat_col_fraction("Sanity", self.sanity, self.max_sanity)
        row += self.stat_col("Composure", self.composure)
        row += self.stat_col("Charisma", self.charisma) + "|"
        print(row)

        print("|" + outputgen.n_char_str("-", constant.OUTPUT_WIDTH - 2) + "|")

        # EQUIPMENT
        self.equipment_row("[1] Head", "head")
        self.equipment_row("[2] Body", "body")
        self.equipment_row("[3] Curio", "curio")
        self.equipment_row("[4] Weapon", "weapon")

        print("|" + outputgen.n_char_str("-", constant.OUTPUT_WIDTH - 2) + "|")
