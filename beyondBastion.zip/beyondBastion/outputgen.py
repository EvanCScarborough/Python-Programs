import constant
from os import system, name
import time

import outputgen


def clear():  # attempts to clear the output window
    if name == 'nt':
        _ = system('cls')
    else:
        _ = system('clear')
    print()


def get_input(max_input, allow_back):  # validates and returns user input as an int
    user_input = ""
    while user_input == "":
        user_input = input(">")

        if user_input.isdigit():
            user_input = int(user_input)

            if user_input < 1:
                if user_input == 0:
                    if allow_back:
                        return user_input
                    else:
                        print("Invalid input.")
                        user_input = ""
                else:
                    print("Invalid input.")
                    user_input = ""
            else:
                if user_input > max_input:
                    print("Invalid input.")
                    user_input = ""
                else:
                    return user_input

        else:
            print("Invalid input.")
            user_input = ""


def n_char_str(c, n):  # generates a string of length n consisting of character c
    string = ""
    for i in range(n):
        string += c
    return string


def divider():
    string = "(" + n_char_str("=", int((constant.OUTPUT_WIDTH - 4) / 2)) + "(O)" + \
             n_char_str("=", int((constant.OUTPUT_WIDTH - 4) / 2)) + ")"
    return string


def print_menu_header(header_text):
    print(divider())
    header_string = "|" + n_char_str(" ", int((constant.OUTPUT_WIDTH - len(header_text)) / 2) - 1) + header_text + \
                    n_char_str(" ", int((constant.OUTPUT_WIDTH - len(header_text)) / 2) - 1)
    while len(header_string) < constant.OUTPUT_WIDTH - 1:
        header_string += " "
    header_string += "|"
    print(header_string)
    print("|" + n_char_str("-", constant.OUTPUT_WIDTH - 2) + "|")


def stat_bar(label, stat, max_stat):
    bar = label + ": "
    bar += n_char_str(" ", constant.BAR_OFFSET - int(constant.OUTPUT_WIDTH / 2))  # offset the stat bar
    for i in range(int((stat / max_stat) * constant.BAR_LENGTH)):
        bar += "█"
    while (len(bar) - constant.BAR_OFFSET + 3) < constant.BAR_LENGTH:
        bar += "░"
    return bar


def print_hud(party):
    print(divider())

    # FIRST ROW OF CHARACTERS
    # row 1
    column_width = int(constant.OUTPUT_WIDTH / 2)

    column1 = ""
    column2 = ""

    # column 1
    column1 += "|  " + party[0].name + ":"  # print leftmost line and character name
    column1 += n_char_str(" ", column_width - len(column1))  # add space until center line

    # column 2
    column2 += "|  "
    if 2 <= len(party):  # if roster contains 2 or more characters
        column2 += party[1].name + ":"  # print center line and character name
    column2 += n_char_str(" ", column_width - len(column2)) + "|"  # add space until outer line

    print(column1 + column2)

    # row 2
    column1 = ""
    column2 = ""

    # column 1
    column1 += "| "  # print leftmost line
    column1 += stat_bar("Health", party[0].health, party[0].max_health)
    column1 += n_char_str(" ", column_width - len(column1))  # add space until center line

    # column 2
    column2 += "| "
    if 2 <= len(party):  # if roster contains 2 or more characters
        column2 += stat_bar("Health", party[1].health, party[1].max_health)
    column2 += n_char_str(" ", column_width - len(column2)) + "|"  # add space until center line

    print(column1 + column2)

    # row 3
    column1 = ""
    column2 = ""

    # column 1
    column1 += "| "  # print leftmost line and energy label
    column1 += stat_bar("Energy", party[0].energy, party[0].max_energy)
    column1 += n_char_str(" ", column_width - len(column1))  # add space until center line

    # column 2
    column2 += "| "
    if 2 <= len(party):  # if roster contains 2 or more characters
        column2 += stat_bar("Energy", party[1].energy, party[1].max_energy)
    column2 += n_char_str(" ", column_width - len(column2)) + "|"  # add space until center line

    print(column1 + column2)

    # row 4
    column1 = ""
    column2 = ""

    # column 1
    column1 += "| "  # print leftmost line and energy label
    column1 += stat_bar("Sanity", party[0].sanity, party[0].max_sanity)
    column1 += n_char_str(" ", column_width - len(column1))  # add space until center line

    # column 2
    column2 += "| "
    if 2 <= len(party):  # if roster contains 2 or more characters
        column2 += stat_bar("Sanity", party[1].sanity, party[1].max_sanity)
    column2 += n_char_str(" ", column_width - len(column2)) + "|"  # add space until center line

    print(column1 + column2)

    # row 5
    column_width = int(constant.OUTPUT_WIDTH / 4)

    column1 = ""
    column2 = ""

    # column 1
    column1 += "|" + n_char_str(" ", column_width) + "Atk: " + str(party[0].attack)  # print leftmost line and character attack
    column1 += n_char_str(" ", int(column_width * 1.5) - len(column1)) + "Def: " + str(party[0].defense)
    column1 += n_char_str(" ", column_width * 2 - len(column1))

    # column 2
    column2 += "|" + n_char_str(" ", column_width)
    if 2 <= len(party):  # if roster contains 2 or more characters
        column2 += "Atk: " + str(party[1].attack)  # print leftmost line and character attack
    column2 += n_char_str(" ", int(column_width * 1.5) - len(column2))
    if 2 <= len(party):  # if roster contains 2 or more characters
        column2 += "Def: " + str(party[1].defense)  # print character defense
    column2 += n_char_str(" ", column_width * 2 - len(column2)) + "|"

    print(column1 + column2)

    # SECOND ROW OF CHARACTERS
    if len(party) >= 3:  # if roster contains 3 or more characters
        print("|" + n_char_str("-", constant.OUTPUT_WIDTH - 2) + "|")
        # row 1
        column_width = int(constant.OUTPUT_WIDTH / 2)

        column1 = ""
        column2 = ""

        # column 1
        column1 += "|  " + party[2].name + ":"  # print leftmost line and character name
        column1 += n_char_str(" ", column_width - len(column1))  # add space until center line

        # column 2
        column2 += "|  "
        if 4 <= len(party):  # if roster contains 4 or more characters
            column2 += party[3].name + ":"  # print center line and character name
        column2 += n_char_str(" ", column_width - len(column2)) + "|"  # add space until outer line

        print(column1 + column2)

        # row 2
        column1 = ""
        column2 = ""

        # column 1
        column1 += "| "  # print leftmost line
        column1 += stat_bar("Health", party[2].health, party[2].max_health)
        column1 += n_char_str(" ", column_width - len(column1))  # add space until center line

        # column 2
        column2 += "| "
        if 4 <= len(party):  # if roster contains 4 or more characters
            column2 += stat_bar("Health", party[3].health, party[3].max_health)
        column2 += n_char_str(" ", column_width - len(column2)) + "|"  # add space until center line

        print(column1 + column2)

        # row 3
        column1 = ""
        column2 = ""

        # column 1
        column1 += "| "  # print leftmost line and energy label
        column1 += stat_bar("Energy", party[2].energy, party[2].max_energy)
        column1 += n_char_str(" ", column_width - len(column1))  # add space until center line

        # column 2
        column2 += "| "
        if 4 <= len(party):  # if roster contains 4 or more characters
            column2 += stat_bar("Energy", party[3].energy, party[3].max_energy)
        column2 += n_char_str(" ", column_width - len(column2)) + "|"  # add space until center line

        print(column1 + column2)

        # row 4
        column1 = ""
        column2 = ""

        # column 1
        column1 += "| "  # print leftmost line and energy label
        column1 += stat_bar("Sanity", party[2].sanity, party[2].max_sanity)
        column1 += n_char_str(" ", column_width - len(column1))  # add space until center line

        # column 2
        column2 += "| "
        if 4 <= len(party):  # if roster contains 4 or more characters
            column2 += stat_bar("Sanity", party[3].sanity, party[3].max_sanity)
        column2 += n_char_str(" ", column_width - len(column2)) + "|"  # add space until center line

        print(column1 + column2)

        # row 5
        column_width = int(constant.OUTPUT_WIDTH / 4)

        column1 = ""
        column2 = ""

        # column 1
        column1 += "|" + n_char_str(" ", column_width) + "Atk: " + str(party[2].attack)  # print leftmost line and character attack
        column1 += n_char_str(" ", int(column_width * 1.5) - len(column1)) + "Def: " + str(party[2].defense)
        column1 += n_char_str(" ", column_width * 2 - len(column1))

        # column 2
        column2 += "|" + n_char_str(" ", column_width)
        if 4 <= len(party):  # if roster contains 4 or more characters
            column2 += "Atk: " + str(party[3].attack)  # print leftmost line and character attack
        column2 += n_char_str(" ", int(column_width * 1.5) - len(column2))
        if 4 <= len(party):  # if roster contains 4 or more characters
            column2 += "Def: " + str(party[3].defense)  # print character defense
        column2 += n_char_str(" ", column_width * 2 - len(column2)) + "|"
        print(column1 + column2)


def menu(header, options, allow_back, clear_output=True):  # given a list of options, prints and formats them and returns user input
    if clear_output:
        clear()
    print_menu_header(header)
    for i in options:
        print("   [{}] ".format(options.index(i) + 1) + i)
    if allow_back:
        print("   [0] Go back")
    return get_input(len(options), allow_back)


def character_menu(party, header):
    clear()
    print_menu_header(header)

    for i in party:
        print("   [{}] ".format(party.index(i) + 1) + i.name.upper())
    print("   [0] Go back")

    user_input = get_input(len(party), True)
    if user_input == 0:
        return 0
    else:
        selected = party[user_input - 1]
        return selected


def continue_prompt():
    print("   [0] Continue")
    return get_input(0, True)


def message_box(header, text):  # given a header and list of strings representing paragraphs, outputs a message box
    clear()
    print_menu_header(header)
    for line in text:
        left_off = 0
        wrap_point = 0
        if len(line) <= constant.OUTPUT_WIDTH - 4:
            print("| " + line + n_char_str(' ', constant.OUTPUT_WIDTH - 4 - len(line)) + " |")  # print that slice
        else:
            while wrap_point < len(line):  # while the whole string has not yet been printed
                wrap_point = left_off + constant.OUTPUT_WIDTH - 4
                if len(line[left_off:len(line)]) > constant.OUTPUT_WIDTH - 4:  # if remaining text is longer than output width
                    while line[wrap_point] != ' ':  # find the nearest whitespace before output width
                        wrap_point -= 1
                else:
                    wrap_point = len(line)  # or just print whatever remains
                segment = line[left_off:wrap_point]  # get slice of string that fits on the line
                left_off = wrap_point + 1
                print("| " + segment + n_char_str(' ', constant.OUTPUT_WIDTH - 4 - len(segment)) + " |")  # print that slice
        if line != text[len(text) - 1]:  # if this paragraph is not the last
            print("|" + n_char_str(" ", constant.OUTPUT_WIDTH - 2) + "|")
    print("|" + n_char_str("-", constant.OUTPUT_WIDTH - 2) + "|")
    continue_prompt()


def main_menu(party, inventory):
    user_input = menu("CHOOSE YOUR NEXT MOVE: ", ["View your inventory", "Manage your party"], False, False)

    match user_input:
        case 1:
            inventory.open(party)
        case 2:
            clear()
            selected_char = character_menu(party, "Select a character")
            if selected_char != 0:
                user_input = menu("Do what with " + selected_char.name + "?", ["View stats", "Kick from party"], True)
                match user_input:
                    case 1:
                        selected_char.stat_sheet()
                    case 2:
                        party.remove(selected_char)
                        print("Kicked " + selected_char.name + " from the party.")
                        outputgen.continue_prompt()
