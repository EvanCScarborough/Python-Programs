import random
import constant

from character import Character
from items.inventory import Inventory

from consumables.health_potion import HealthPotion
from consumables.energy_potion import EnergyPotion
from consumables.sanity_potion import SanityPotion
from items.equipment.generic_helmet import GenericHelmet
from items.equipment.generic_armor import GenericArmor
from items.equipment.generic_shortsword import GenericShortsword


from location import Location


def locations():
    neleith = Location("Neleith, the Mountain's Crown", "Neleith", 10, 23)
    merredark = Location("Merredark, City of Stone", "Merredark", 4, 9)
    atlas = [neleith, merredark]
    return atlas


def characters():
    roster = []

    tester = Character("Tester", "they", random.randint(5, constant.STAT_CAP - 5),
                       random.randint(5, constant.STAT_CAP - 5),
                       random.randint(5, constant.STAT_CAP - 5),
                       random.randint(5, constant.STAT_CAP - 5),
                       random.randint(5, constant.STAT_CAP - 5),
                       random.randint(5, constant.STAT_CAP - 5))
    roster.append(tester)

    gombus = Character("Gombus", "they", random.randint(5, constant.STAT_CAP - 5),
                       random.randint(5, constant.STAT_CAP - 5),
                       random.randint(5, constant.STAT_CAP - 5),
                       random.randint(5, constant.STAT_CAP - 5),
                       random.randint(5, constant.STAT_CAP - 5),
                       random.randint(5, constant.STAT_CAP - 5))
    roster.append(gombus)

    url = Character("URL", "they", random.randint(5, constant.STAT_CAP - 5),
                    random.randint(5, constant.STAT_CAP - 5),
                    random.randint(5, constant.STAT_CAP - 5),
                    random.randint(5, constant.STAT_CAP - 5),
                    random.randint(5, constant.STAT_CAP - 5),
                    random.randint(5, constant.STAT_CAP - 5))
    roster.append(url)

    rupert = Character("rupert", "they", random.randint(5, constant.STAT_CAP - 5),
                       random.randint(5, constant.STAT_CAP - 5),
                       random.randint(5, constant.STAT_CAP - 5),
                       random.randint(5, constant.STAT_CAP - 5),
                       random.randint(5, constant.STAT_CAP - 5),
                       random.randint(5, constant.STAT_CAP - 5))
    roster.append(rupert)

    return roster


def items():
    item_registry = []

    entry = HealthPotion("Sallow Ambrosia", 0.8, 10, False, True, True)
    item_registry.append(entry)

    entry = EnergyPotion("Feverbriar Snuff", 0.3, 10, False, True, True)
    item_registry.append(entry)

    entry = SanityPotion("Bottled Gravedew", 0.6, 10, False, True, True)
    item_registry.append(entry)

    entry = GenericHelmet("Helmet")
    item_registry.append(entry)

    entry = GenericArmor("Plate Armor")
    item_registry.append(entry)

    entry = GenericShortsword("Shortsword")
    item_registry.append(entry)

    return item_registry


def inventory():
    inv = Inventory()

    return inv
