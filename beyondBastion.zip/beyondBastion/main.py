import outputgen
import init
from items.item_stack import ItemStack

roster = init.characters()
atlas = init.locations()
items = init.items()
inventory = init.inventory()

party = [roster[0], roster[1], roster[2], roster[3]]

for i in items:
    test_stack = ItemStack(i, 1)
    inventory.add(test_stack)

user_input = ""
while user_input != "q" and user_input != "quit":
    outputgen.clear()

    outputgen.print_hud(party)
    outputgen.main_menu(party, inventory)
