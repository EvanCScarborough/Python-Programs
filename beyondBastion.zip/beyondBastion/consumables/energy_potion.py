from items.item import Item


class EnergyPotion(Item):
    def __init__(self, name, weight, value, usable, consumable, destructible):
        super().__init__(name, weight, value, usable, consumable, destructible)
        self.description = ["Coarse brown powder made from the dried leaves of the feverbriar plant. Hastens the heart "
                            "and causes mild visual distortions.",
                            "Restores Energy at the cost of Health and Sanity."]

    def consume(self, consumer):
        consumer.energy += round(consumer.max_energy * 0.2)
        if consumer.energy > consumer.max_energy:
            consumer.energy = consumer.max_energy

        consumer.take_damage("health", 6)
        consumer.take_damage("sanity", 4)
        return True
