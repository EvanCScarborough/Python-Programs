from items.item import Item


class HealthPotion(Item):
    def __init__(self, name, weight, value, usable, consumable, destructible):
        super().__init__(name, weight, value, usable, consumable, destructible)
        self.description = ["Distillate from the waters of Marzeth, the Infinite Spring. So called for the pale yellow"
                            " color that tints the gaunt faces of those addicted to it.",
                            "Restores Health at the cost of Sanity and Energy."]

    def consume(self, consumer):
        consumer.health += round(consumer.max_health * 0.2)
        if consumer.health > consumer.max_health:
            consumer.health = consumer.max_health

        consumer.take_damage("sanity", 6)
        consumer.take_damage("energy", 4)
        return True
