from items.item import Item


class SanityPotion(Item):
    def __init__(self, name, weight, value, usable, consumable, destructible):
        super().__init__(name, weight, value, usable, consumable, destructible)
        self.description = ["When dawn breaks in the world above, and the dew upon the headstones soaks into the "
                            "earth, a few precious drops trickle down Anvara's roots into the world below - a gentle "
                            "reminder of home.",
                            "Restores Sanity at the cost of Health and Energy."]

    def consume(self, consumer):
        consumer.sanity += round(consumer.max_sanity * 0.2)
        if consumer.sanity > consumer.max_sanity:
            consumer.sanity = consumer.max_sanity

        consumer.take_damage("health", 6)
        consumer.take_damage("energy", 4)
        return True
