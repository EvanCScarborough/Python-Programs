class Location:
    def __init__(self, fullname, name, x, y):
        self.fullname = fullname
        self.name = name
        self.x = x
        self.y = y
