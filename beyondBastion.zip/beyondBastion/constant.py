OUTPUT_WIDTH = 81  # maximum width of all outputs
BAR_LENGTH = 28  # length of stat bars in HUD
BAR_OFFSET = 11  # how far from the left the stat bars in main hud should be offset to make room for label
STAT_CAP = 50  # hard cap for character attributes
STAT_CONVERSION = 2.5  # value to multiply vitality, endurance, composure by to get health, energy, sanity bonus
