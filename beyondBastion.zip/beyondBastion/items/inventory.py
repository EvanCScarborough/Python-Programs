import outputgen
import constant
import time

from items.equipment.equipment import Equipment


def on_whom(party, item_stack):
    print(outputgen.n_char_str("-", constant.OUTPUT_WIDTH))
    print(" Use the " + item_stack.item.name + " on whom?")
    print(outputgen.n_char_str("-", constant.OUTPUT_WIDTH))

    for i in party:
        print("   [{}] ".format(party.index(i) + 1) + i.name.upper())
    print("   [0] Go back")

    user_input = outputgen.get_input(len(party), True)
    if user_input == 0:
        return 0
    else:
        selected = party[user_input - 1]
        print(" Used " + item_stack.item.name + " on " + selected.name + ".")
        return selected


def get_max_weight(party):
    max_weight = 0
    for member in party:
        max_weight += member.strength * 3 + 20
    max_weight = round(max_weight, 2)
    return max_weight


class Inventory:

    def __init__(self):
        self.contents = []

    def add(self, item_stack):
        for i in self.contents:
            if i.item == item_stack.item:
                i.count += item_stack.count
                return
        self.contents.append(item_stack)

    def remove(self, item_stack, quantity=1):
        for i in self.contents:
            if i.item == item_stack.item:
                i.count -= quantity
                if i.count <= 0:
                    self.contents.remove(i)
                return

    def get_current_weight(self):
        current_weight = 0
        for item_stack in self.contents:
            current_weight += item_stack.item.weight * item_stack.count
        current_weight = round(current_weight, 2)
        return current_weight

    def get_item_stack(self):
        user_input = outputgen.get_input(len(self.contents), True)
        if user_input == 0:
            return user_input
        else:
            stack = self.contents[user_input - 1]
            return stack

    def open(self, party):
        outputgen.clear()
        outputgen.print_menu_header("INVENTORY")
        for stack in self.contents:
            entry = "| [" + str((self.contents.index(stack) + 1)) + "] " + stack.item.name  # print the item name

            entry += outputgen.n_char_str(" ", 26 - len(entry) - len(str(stack.count)))\
                + " x" + str(stack.count)  # print the count

            weight_string = "{:.1f}lbs".format(stack.item.weight * stack.count)
            entry += outputgen.n_char_str(" ", 37 - len(entry) - len(weight_string))\
                + weight_string

            entry += outputgen.n_char_str(" ", 42 - len(entry) - len(str(stack.get_value())))\
                + str(stack.get_value()) + "gr"

            entry += outputgen.n_char_str(" ", 46 - len(entry))
            if issubclass(type(stack.item), Equipment):
                num_printed = 0
                modifier_list = stack.modifiers
                for modifier_name in modifier_list:
                    if modifier_list[modifier_name] > 0:
                        num_printed += 1
                        if num_printed >= 2:
                            entry += ", "
                        entry += modifier_name + " +" + str(modifier_list[modifier_name])
                    elif modifier_list[modifier_name] < 0:
                        num_printed += 1
                        if num_printed >= 2:
                            entry += ", "
                        entry += modifier_name + " " + str(modifier_list[modifier_name])

            entry += outputgen.n_char_str(" ", constant.OUTPUT_WIDTH - len(entry) - 1) + "|"
            print(entry)
        weight_fraction = "{:.1f} / {:.1f} lbs".format(self.get_current_weight(), get_max_weight(party))
        entry = "|" + outputgen.n_char_str(" ", constant.OUTPUT_WIDTH - 4
                                           - len(weight_fraction)) + weight_fraction + "  |"
        print(entry)
        print(outputgen.divider())
        selected_stack = self.get_item_stack()  # allow the player to select an item or return 0
        if selected_stack != 0:
            options = []
            if isinstance(selected_stack.item, Equipment):  # if item inherits from Equipment
                options.append("Equip")
            if selected_stack.item.is_usable:
                options.append("Use")
            if selected_stack.item.is_consumable:
                options.append("Consume")
            if selected_stack.item.description != "":
                options.append("Examine")
            if selected_stack.item.is_destructible:
                options.append("Destroy")
            user_input = outputgen.menu(" Do what with the " + selected_stack.item.name + "?", options, True)
            if user_input != 0:
                chosen = options[user_input - 1]
                match chosen:
                    case "Equip":
                        selected_char = outputgen.character_menu(party, "Who should equip the " + selected_stack.item.name + "?")
                        if selected_char != 0:
                            self.equip(selected_char, selected_stack)
                            time.sleep(2)
                    case "Use":
                        selected_char = on_whom(party, selected_stack)
                        if selected_char != 0:
                            selected_stack.item.use(selected_char)
                            time.sleep(2)
                    case "Consume":
                        selected_char = outputgen.character_menu(party, "Use the " + selected_stack.item.name + " on whom?")
                        if selected_char != 0:
                            if selected_stack.item.consume(selected_char):
                                self.remove(selected_stack, 1)
                                print("Gave a " + selected_stack.item.name + " to " + selected_char.name + ".")
                                time.sleep(2)
                    case "Examine":
                        selected_stack.item.examine()
                    case "Destroy":
                        outputgen.print_menu_header("Destroy how many " + selected_stack.item.name + "s?")
                        user_input = outputgen.get_input(selected_stack.count, True)
                        if user_input != 0:
                            self.remove(selected_stack, user_input)
                            print("Destroyed " + selected_stack.item.name + " x " + str(user_input) + ".")
                            time.sleep(2)

    def equip(self, character, stack):  # returns true if item was successfully equipped
        if character.equipment[stack.item.slot] is None:  # if destination slot is empty
            character.equipment[stack.item.slot] = stack  # equip the item
            print(character.name + " has equipped " + character.equipment[stack.item.slot].item.name + ".")
            self.remove(stack)
            character.update_stats()
            return True
        else:  # else prompt the player to confirm swapping with item already equipped
            swap_confirm = outputgen.menu("Replace " + character.equipment[stack.item.slot].item.name + " with " + stack.item.name + "?",
                                          ["Yes", "No"], False)
            if swap_confirm == 1:
                self.add(character.equipment[stack.item.slot])  # put the old item back in inventory
                character.equipment[stack.item.slot] = stack
                print(character.name + " has equipped " + character.equipment[stack.item.slot].item.name + ".")
                self.remove(stack)
                character.update_stats()
                return True
            else:
                return False

