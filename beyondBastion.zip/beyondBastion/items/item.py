import outputgen

class Item():
    def __init__(self, name, weight, value, usable, consumable, destructible=True):
        self.name = name
        self.weight = weight
        self.value = value
        self.is_usable = usable
        self.is_consumable = consumable
        self.is_destructible = destructible
        self.description = ["Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum"]

    def use(self, target):  # should return 1 if using the item destroys it
        pass

    def consume(self, consumer):  # should return 1 if consuming the item destroys it
        pass

    def examine(self):
        outputgen.message_box(self.name, self.description)
