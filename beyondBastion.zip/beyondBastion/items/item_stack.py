from items.equipment.equipment import Equipment

class ItemStack:
    def __init__(self, item, count):
        self.item = item
        self.count = count

        self.value = 0
        self.weight = 0

        self.atk_mod = 0
        self.def_mod = 0
        self.str_mod = 0
        self.int_mod = 0
        self.cha_mod = 0
        self.vit_mod = 0
        self.end_mod = 0
        self.com_mod = 0

        self.modifiers = {"ATK": self.atk_mod, "DEF": self.def_mod, "STR": self.str_mod, "INT": self.int_mod,
                          "CHA": self.cha_mod, "VIT": self.vit_mod, "END": self.end_mod, "COM": self.com_mod}

        if issubclass(type(item), Equipment):
            self.modifiers = item.init_modifiers()

        self.get_value()

    def get_value(self):
        self.value = self.item.value
        for i in self.modifiers:
            self.value += round(self.modifiers[i] * self.item.value * 0.2)
        return self.value
