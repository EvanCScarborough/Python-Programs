from items.item import Item


class Equipment(Item):
    def __init__(self, name, weight, value, slot, usable=False, consumable=False, destructible=True):
        super().__init__(name, weight, value, usable, consumable, destructible)
        self.slot = slot  # "head", "body", "weapon", or "curio"

    def init_modifiers(self):
        atk_mod = 0
        def_mod = 0
        str_mod = 0
        int_mod = 0
        cha_mod = 0
        vit_mod = 0
        end_mod = 0
        com_mod = 0

        modifiers = [["ATK", atk_mod], ["DEF", def_mod], ["STR", str_mod], ["INT", int_mod],
                     ["CHA", cha_mod], ["VIT", vit_mod], ["END", end_mod], ["COM", com_mod]]
        return modifiers
