class AttributeModifier:
    def __init__(self, attribute_name, modifier):
        self.name = attribute_name
        self.modifier = modifier
