from items.equipment.equipment import Equipment
import random


class GenericHelmet(Equipment):
    def __init__(self, name):
        super().__init__(name, 6, 12, "head")
        self.description = ["Unremarkable iron helmet, scratched and worn from years of use."]

    def init_modifiers(self):
        atk_mod = 0
        def_mod = random.randint(1, 4)
        str_mod = 0
        int_mod = 0
        cha_mod = random.randint(-1, 2)
        vit_mod = 0
        end_mod = -random.randint(0, 2)
        com_mod = 0

        modifiers = {"ATK": atk_mod, "DEF": def_mod, "STR": str_mod, "INT": int_mod,
                     "CHA": cha_mod, "VIT": vit_mod, "END": end_mod, "COM": com_mod}

        return modifiers
