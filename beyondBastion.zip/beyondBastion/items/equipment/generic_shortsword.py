from items.equipment.equipment import Equipment
import random


class GenericShortsword(Equipment):
    def __init__(self, name):
        super().__init__(name, 3, 14, "weapon")
        self.description = ["Double-edged blade that tapers to a dull point. Only just in usable condition."]

    def init_modifiers(self):
        atk_mod = random.randint(3, 6)
        def_mod = 0
        str_mod = 0
        int_mod = 0
        cha_mod = random.randint(-1, 2)
        vit_mod = 0
        end_mod = -random.randint(0, 2)
        com_mod = 0

        modifiers = {"ATK": atk_mod, "DEF": def_mod, "STR": str_mod, "INT": int_mod,
                     "CHA": cha_mod, "VIT": vit_mod, "END": end_mod, "COM": com_mod}

        return modifiers
